#!/bin/bash

if [ $# -ne 1 ]; then
	echo "Uso: $0 <nombre_del_proceso>"
	exit 1
fi


nombre_proceso="$1"

if pgrep -x "$nombre_proceso" > /dev/null; then
	echo "El proceso '$nombre_proceso' esta en ejecucion."
else
	echo "El proceso '$nombre_proceso' no esta en ejecucion en el servidor"
	echo "El proceso '$nombre_proceso' no esta en ejecucion en el servidor" | mutt -s "Alerta de Monitoreo" root
fi


