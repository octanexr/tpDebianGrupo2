#!/bin/bash

# Varibales
backup_dir="/u03"
backup_name="backup_full.tar.gz"
fecha=$(date "+%Y%m%d")
hora=$(date "+%H:%M:%S")

#Funciones
function log_action(){
	local action="$1"
	local mensaje="$2"
	
	#Formateo la hora
	local hora=$(date +"%H:%M:%S")

	#Escritura del log
	echo "$hora - $action - $mensaje" >> backup.log
}


manual(){
	echo "-o (origen) directorio a backupear"
	echo "-d (destino) directorio donde se guarda el backup"
	echo "-h ayuda"
	exit 1
}	

while getopts "o:d:h" opt; do
	case $opt in
	o) origen="$OPTARG";;
	d) destino="$OPTARG";;
	h) manual;;
	esac
done


#Validacion de argumentos
if [ -z "$origen" ] || [ -z "$destino" ]; then
	echo "Uso: $0 -o <origen>  -d <destino>"
	exit 1
fi

#Validacion de la existencia de los filesystems
if [ ! -d "$origen" ]; then
	echo "El filesystem origen '$1' no existe"
	exit 1
fi

if [ ! -d "$destino" ]; then
	echo "El filesystem '$2' no existe"
	exit 1
fi

nombre_backup="$(basename $origen)_backup_${fecha}_${hora}.tar.gz"

#Creacion del backup
log_action "Creando backup"
tar -czf ${destino}/$nombre_backup $origen

#Envio el log por mail
log_action "Enviando log por mail"
mutt -s "Backup completo" root < backup.log

exit 0

