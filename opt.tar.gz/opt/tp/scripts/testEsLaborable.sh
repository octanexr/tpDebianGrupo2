#! /bin/bash

if [ -z "$1" ]; then
  echo "Debes proporcionar argumento."
  echo 1
fi

source /opt/tp/scripts/esLaborable.sh

fecha="$1"
esLaborable "$fecha"

