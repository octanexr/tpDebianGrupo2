#!/bin/bash

function esLaborable(){

if [ -z "$1" ]; then
  echo "Debes proporcionar argumentos."
  exit 1
fi

fecha=$1
DAY=$(date -d "$fecha" '+%d')
MONTH=$(date -d "$fecha" '+%m')

dia_semana=$(date -d "$fecha" +%u)
semana_mes=$((($(date -d "$fecha" +%-d)-1)/7+1))

case "$MONTH-$DAY" in "01-01" | "03-24" | "04-02" | "05-01" | "05-25" | "06-20" | "07-09" | "12-08" | "12-25")
  echo "No es laborable por ser feriado nacional no movible de día."
  return ;;
 "08-17" | "10-12" | "11-20")
 if [ "$dia_semana" -eq 1 ]; then
   echo "No es laborable por ser feriado nacional de los que se pueden mover pero por haber caído lunes no se mueve."
   return
 fi
 ;;
esac

if [ "$MONTH" = "08" ] && [ "$dia_semana" -eq 1 ] && [ "$semana_mes" -eq 3 ]; then
  echo "No es laborable por el feriado del 17-08 que, por no haber caído lunes se mueve para el tercer lunes del mes de agosto."
  return
fi

if [ "$MONTH" = "10" ] && [ "$dia_semana" -eq 1 ] && [ "$semana_mes" -eq 2 ]; then
  echo "No es laborable por el feriado del 12-10 que, por no haber caído lunes se mueve para el segundo lunes del mes de octubre."
  return
fi

if [ "$MONTH" = "11" ] && [ "$dia_semana" -eq 1 ] && [ "$semana_mes" -eq 4 ]; then
 echo "No es laborable por el feriado del 20-11 que, por no haber caído lunes se mueve para el cuarto lunes del mes de noviembre."
 return
fi

if [ "$dia_semana" -eq 6 ] || [ "$dia_semana" -eq 7 ]; then
  echo "No es laborable por ser fin de semana."
  return
fi

echo "Es laborable."

}

